///////////////////////////////////
///////welcome////////////////////
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


How to decode...
____________________________________________________________________________
1. go to https://pageloot.com/qr-code-scanner/#upload 
	and upload 1, then 2, then 3, and then 4.

	after scaning 1 copy the contents and paste them into a file called yourfile.bat
	make sure it's extention is .bat or this will not work.
	repeat the above until final game.

___________________________________________________________________________________________________________________
2. run each file from 1 to final and if you did all correct it will always say at the end of the batch script...
												scan code X.
___________________________________________________________________________________________________________________
3. enjoy!

